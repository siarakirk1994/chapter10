/*
    Student Name:
    File Name: script.js
    Date: 
*/

//Function to display the first picture
function pic1 {
    imgSource.src = "images/trunk-bay.jpg"
    imgSource.alt = Elevated view of Trunk Bay beach on St. John";
    figElement.style.display = "block
    figCap.textContent = "Trunk Bay in St. John";
